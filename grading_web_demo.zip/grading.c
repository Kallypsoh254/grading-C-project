
#include <stdio.h>
#include <string.h>

#define MAX_ID_LEN 10
#define MAX_NAME_LEN 50

// Simulated data
typedef struct {
    int id;
    char name[MAX_NAME_LEN];
    char admission[MAX_ID_LEN];
} Student;

typedef struct {
    int id;
    char name[MAX_NAME_LEN];
    char adminID[MAX_ID_LEN];
} Admin;

Student students[] = {
    {1, "Alice", "S1001"},
    {2, "Bob", "S1002"}
};

Admin admins[] = {
    {1, "Mr. Smith", "A2001"},
    {2, "Mrs. Johnson", "A2002"}
};

// Simulated student menu
void studentMenu(int id) {
    printf("Student Menu for ID %d\n", id);
    printf("1. View Grades\n2. Logout\n");
}

// Simulated admin menu
void adminMenu() {
    printf("Admin Menu\n1. Enter Grades\n2. View All Students\n3. Logout\n");
}

// Login as student
int loginAsStudent(const char* enteredID) {
    for (int i = 0; i < 2; i++) {
        if (strcmp(enteredID, students[i].admission) == 0) {
            printf("Welcome, %s!\n", students[i].name);
            studentMenu(students[i].id);
            return students[i].id;
        }
    }
    printf("Invalid Admission Number!\n");
    return -1;
}

// Login as admin
int loginAsAdmin(const char* enteredID) {
    for (int i = 0; i < 2; i++) {
        if (strcmp(enteredID, admins[i].adminID) == 0) {
            printf("Welcome, %s!\n", admins[i].name);
            adminMenu();
            return admins[i].id;
        }
    }
    printf("Invalid Admin ID!\n");
    return -1;
}

// Main exposed entry for WebAssembly
int main() {
    printf("Grading System Web Demo Loaded.\n");
    return 0;
}
